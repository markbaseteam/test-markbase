This is a common thing in Math.

NAT --> Ring
nat.add --> +
nat.mul --> *
nat.0 --> 0
nat.1 --> 1
nat.divide(x,y) <-> ex(k in NAT) { y = nat.mul(x,k) } -----> ring.divide(R)(x,y) <-> ex(k in base(R)) { y = ring.mul(R)(x,k) }
irreducible(x) <-> ( all y, z: x = y.z -> unit(y) or unit(z) ) ------> ring.irreducbile(R)(x) <-> ( all y, z: x = y.z -> unit y or unit z )

* we have a system of symbols (relation, function, constants)
* we have a transformation map from concrete situation --> general situation.
* definitions must be the same

There're 2 approaches to capture this very concept: category-theory-spirit and above generalization.

Category-theory-spirit approach is the fashion when we care about *how It behaves*. And here we care about *how it looks like*.

For instance, we have a concept *prime*. How it looks, we carry the same structural definition: p | xy -> p | x or p | y. It comes from divides relationship. So we define prime for generalized structure in the same way we define for concrete structure. *We don't care how it behaves*. For instance, we might have irreducible implies prime in NAT/INT but we don't have that in general ring.

The category-theory-spirit approach is, we only care about *desired property*. Our 1st interest is how it works, in this case, is we desire to have a property that satisfies: irreducible(x) -> prime(x). Then we call it's *the prime property*. *We don't care how It being defined*.

Why is that? The category-theory-spirit is also good. It focuses on the result. With that result, we have a stone to keep developing the upcoming properties. Like, if in our proof, we need a property foo as a step of proof to imply property blah. Then category-spirit will define anything that holds property foo by a name. Then Foo implies Blah is what Category theory achieves.

It has advantages and disadvantages too.
**Category-spirit approach advantages and disadvantages**:
* It focuses on desired property. But there's no way to tell how to define that property. How to have that one?
* Sometimes we have few definitions for a desired pattern. Like homeomorphic, isotopic..

**Structural-def approaches**:
* The general definition never satisfies ALL properties the concrete definition holds. Yes, because It's general. Concrete example is stronger to prove things hence It can prove more.
* We can slice our objects into 2 parts. A part that doesn't hold desired property. A part that holds. For instance, rings that hold UF is called UFD. Rings that hold principal ideal property is called PID.. so on. That enlarges our knowledge about this concept. And It provides us a picture of the original object. Where it is in the whole picture? Like Earth is where we have human, food, oxygen.. All planets don't hold this property. We know where Earth is in the whole picture of planets in our universe.
# Some observations
Let we want to generalize a definition d from NAT -> Ring.
We have a transformation map $\Gamma$ : 
A definition d in *NAT World*
* params: (x,y)
* context: fix22(in,NAT)(x), fix22(in,NAT)(y)
* definiens: it <-> ex( k: fix22(in,NAT)(k) ) { y = nat.mul(x,k) }

Now we wanna generalize this. Generalize in this situation, is understood as bring a definition from NAT world to Ring world.
base context: Ring(A), + = ring.add(A), $\cdot$ = ring.mul(A)
* params: (x,y). This is no big deal. We can choose new params
* context: here we have T1(x), T1(y) is the condition of x, y. We'll need to translate those terms. We translated them to fix22(ring.in,A)(x), fix22(ring.in,A)(y)
* definiens: it <-> ex( k: fix22(ring.in)(A)(k) ) { y = ring.mul(A)(x,k) }

Ok, It's a simple case. So $\Gamma$ must transform terms --> terms. And we need a policy for it first.
* $\Gamma$(NAT) = A
* $\Gamma$(fix22(in,NAT)) = fix22(ring.in,A)
* if we go further, we actually want $\Gamma$(in) = ring.in. It makes sense this case because $\in$ is also just a relation.
* $\Gamma$(=) is =, it's identical for the relationship equal: =. However, this is not generally true. Sometimes, we even replace equal by certain equivalence relation. Oh, very close example: p prime and x | p then x = 1 or x = p in NAT. But for rings, p prime, x | p then x ~ 1 or x ~ p, where ~ here is associate relationship.
* $\Gamma(\exists) = \exists$ in this situation. But generally, It's not true. I don't think of any example for exist, but I have example for exists uniquely. Sometimes, exists uniquely becomes exists uniquely up to something.
* $\Gamma$(nat.mul) = ring.mul(A)

Okay, hence generalization is actually a map from one world into another world. And d is a concept in world 1 then its generalization is a concept in world 2. Hmm, we need to define the concept World here as well #tdmath

**A Transformation map**:
* It maps constant --> constant, like NAT to A. It maps other constants too, like nat.0, nat.1..
* relation --> relation: like in to ring.in, or eq --> $\cong$
* function --> function: like nat.mul --> ring.mul(A). It maps other functions too, like nat.add..
* quantifier --> quantifier

Then from that we can build a map from terms -> terms. In Model theory, It's a homomorphism between 2 models. I think it's same here. However, here It's not in discipline of model theory.

* A world is not a model. It's a collection of some: defs, terms. It's not some constant because if we observe a phenomenon in $\mathbb{N} \times \mathbb{N}$ this case, then It's a term, not a constant (atomic term). Some defs here cover all types of defs: relation, function, quantifier..
* A world under context: Here (A,+,.,0,1...) is a world but It's under context C: A is a ring, 0 = ring.zero(A), 1 = ring.unit(A), + = ring.add(A)..

Given a world W. A term t is called a W-term if t is built from defs and terms of W. Hmm, but this definition is a bit vague. We're in a common place, a common universe all of terms. How can we say W-term? Here we use $\in$, or $\cap$ they're common symbols. Ok. So It doesn't make sense to define W-term.

Hmm, but we have W-fact? W-fact is about facts of W. We consider all symbols are equal in our theory. So +, ., 0, 1, <=.. they're treated all the same. They're all considered as objects. So nat.divide is also an object. nat.prime, nat.irreducible.. are all objects.

We have nat.irreducible ~ nat.prime is a f act about 2 objects. We have a theorem:
all(n:fix22(in,NAT)(n)) { nat.irreducible(n) <-> nat.prime(n) }

we define R1 ~ R2 if $zfc \vdash \forall( x: C(x) ) { R1(x) \iff R2(x) }$. Here C is common condition of R1, R2. When we have R1 ~ R2 in the world NAT, we may say it's an event in that world. For corresponding $\Gamma(R_1), \Gamma(R_2)$ we may have or not have similar $\Gamma(R_1) \sim \Gamma(R_2)$ event.

[[Chain of concepts]]