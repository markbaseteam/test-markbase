Decomposition. Independent.

A **decomposition** of X is a list $A_1,.. A_n$ such that $X = \bigoplus A_j$ . Hence here, decomposition is not a static concept. It refers to dependent concepts:
* direct sum: X = direct.sum(A). There's a *direct sum concept D* here.
* A must be a finite sequence of objects in same type as X. Like X is group, then each A_j must be a group. X is a vector space over field F, then each Aj must be a vector space over field F. X is abelian group then each Aj must be abelian group to make sense. Hmm, so It has a parameter: *type T*. In practice, T is sub-group of fixed abelian group M. T is R-module. T is F-vector.space.
* To have sense of decomposition, we need an order: $A_j \le X$ for all j. That's *order for type T*.
* To have sense of decomposition, we need each Aj is pairwise equal or disjoint.
	* equal here can sometimes be equivalent, like prime decomposition in a ring
	* we need a concept *disjoint for type T*. For instance disjoint for primes means they're not associate. But disjoint for abelian groups means their intersection is zero group.

So a decomposition concept is a definition but it relates to few other definitions: type T, direct sum D, finite sequence of type T.

With category-spirit approach, we use arrows to define decomposition. And we define direct sum in the way its property works. We often have direct sum works this way: f_j is injection map from A_j to X. And it holds certain universal property, certain diagram idk. It's a very good and wise approach. I love that too. Just don't know how to build such a thing. And sometimes, we have decomposition and just don't have nice property for that decomposition. But that decomposition is still worth working with.

decomposition d is a def:
* parameters: X, A
* context: T(X) for some type T. Sometimes, T(X) & $\varphi(X)$, (finite.sequence of T)(A)
* definiens: it <-> X = D(A)

here, we write d(X,A) if A is a decomposition of X. But in hidden graph of things, we know that d depends deeply on the definition of direct sum D. And we need  a mean to express this thing. Or just consider it as a phenomenon.

We often write ring.decomposition, abelian_group.decomposition if we want to distinguish it from others. However, It's not the point. To have d being considered as "decomposition", It must hold our criteria to be a decomposition.

Our meta definition here is: a def d is called a **decomposition** def of type T, direct sum D if it holds:
* context(d): T(X) + finite.sequence(T)(A)
* definiens(d): it $\leftrightarrow$ X = D(A)

Yes, that's the structure of a decomposition. Here we have a relationship of 3 objects: d, T, D. From each T, D we have a unique concept d so we can write d = the.decompostion(T,D). It's a math function of objects: T, D. A real math function of 2 objects T and D.

In this case, we can write the.decompostion(T,D)(X,A) in case we wanna define.

Next, D is call a direct sum.
* parameters: A
* context: A is finite sequence of T, each i,j in dom(A), Ai, Aj is similar or pairwise disjoint.
* definiens: It's an induction def.
But we know it depends few things:
* similar concept.
* disjoint concept

we can consider similar is equal for simplicity.
disjoint is a def:
* params: A, B
* context: T(A), T(B)
* definiens: it <-> $A \cap B$ = 0

And all of this chain, we have chain of defs. If we don't write t = decomposition(T,D)(X,A), we write only d(X,A) then we have a small graph of those concepts. And 2 worlds: prime decomposition and abelian decomposition work the same way this time.

Hmm, this is about: we have an *ecosystem* of some defs:

base-context: abelian group(M)
* **T**: fix22(subgroup,M) is a type.
* **disjoint** is a def having context **T**(var), **T**(var2)
* **direct.sum** is a def having context: finite.sequence(T)(A) & pairwise(disjoint)(A)
	* definiens of direct.sum use the product p, it's p = group.subgroup_mul(M) so we can write p(x,y) means x.y
* **decomposition** is def having context: T(var), finite.sequence(T)(A) & pairwise(disjoint)(A)

we often use the the word: with respect to: (wrt).

D1 is direct.sum wrt the disjoint concept disjoint1, type T1, product p
D2 is direct.sum wrt the disjoint concept disjoint2, type T2, product p

If we change: 
* T to be fix22(in,NAT)
* disjoint2(x,y) <-> $x \nmid y$ & $y \nmid x$ 
* product p to be nat.mul

we have: condition for direct.sum is A is a finite sequence of element of NAT & pairwise(disjoint2)(A).
And now the direct.sum is the concept of product of 90 = 2x9x5, or 90 = 9x10. But 3x30 doesn't work while sequence (3,30) doesn't hold pairwise disjoint condition.

Things concerned here:
* a type T
* a disjoint concept
* a product concept.

For those, we have a direct sum concept. But we want a sense of direct sum. We need a partial order to have sense of direct sum. For instance, face: all j in dom(A) then $A_j \le \bigoplus{A_k}$ . For instance, if we define it for ideals, we don't have I <= IJ. So IJ doesn't feel like a direct sum of I and J. However, I <= $I + J$ hence we feel like It's a sum.

If we don't have that fact, we don't have sense of *sum*. And the direct part comes from the *disjoint part*. We may define disjoint differently for integers. x disjoints y if x != y. or it can be gcd(x,y) = 1. Or it can be neither x, y divides the other.

Idk exactly but there's a relationship between chain of concepts, and 2 different worlds, and their connections, and generalization.

We don't blindly generalize stuffs. We generalize things based on *certain sense*.

Like $A_j \le \bigoplus{A_k}$ is a sense. We don't use symbol $\bigoplus$ for the consecutive division. We also use that when $+$ is abelian.

Hmm, *sense of +* is: 
* x + y = y + x
* x + 0 = 0 + x
* x + ( y + z ) = (x + y) + z

Also, that's the property of +. We have *different senses* for different things:
* independent
* dependent
* locally
* pairwise
* span
* generated
* disjoint
* completely

X is called *independent* if there's no x in X can be represented via X\\{x}. That's one type of sense.

Another type of sense if if y is an expression by elements of X, y = 0 then all coefficients = 0. That's what we define independence for modules and vector spaces.

2 senses are identical in case of vector spaces. But It's not true for modules in general. But that's not the problem.

A sense is an idea for us to develop new definitions. if we observe that there's a phenomenon or few phenomena in certain world, we my want to replicate them in other worlds. Why? Because we have no other sources. We only rely on existing phenomena to develop.

independent(X) <-> all(x, x *in* X) { x can't be *expressed* via X\\{x} }

Ok, that's interesting point. That's a property of *independent*. We have sense of independent again if we see the same pattern:
foo(A) <-> all( a, a in A ) { a can't be expressed via A\\{a} }
of course, we have corresponding concept "express" here. This express concept must be the same sense as above concept.

Above concept, x can't be expressed via X\\{x}, or ! representable(x,X\\{x}), we have a binary relation: representable.

We can simplify it by span: representable(x,U) <-> x in span(U)

So we require sense of *span*. Ok, span is just unary function, defined on subsets. It holds:
* *$U \subseteq span(U)$ 
* span(span(U)) = span(U)

say, the closure $\bar{A}$ of topological space is kind of span. if $x \notin$ $\overline{X \setminus \{x\} }$ for all x in X. Then which type of set are we talking to? Hmm, for instance in $\mathbb{R}^2$ this type of set is quite *discrete* to me. It contains no disc. It has no limit points. Ok, independent here in this sense, means It has no limit points.

It's not quite interesting for the context of Topology. But this this type of independence can be applied to be idea to define new things in some other cases.

Another type of independence is, if E is an expression of elements of X, and valuation(E) = zero_1, then coefficients(E) = zero_2.
For this, we need: expression, coefficient, zero_1, zero_2, valuation.
* for linear algebra, expression is linear expression.
* coefficients(E) = set of scalars
* zero_1 = zero of vector space
* zero_2 = zero of field
* valuation of E, is just its sum: $r_1.x_1 + .. + r_n.x_n$ 

This type of independence can be used for algebraically independent: We say $\alpha$ and $\beta$ are algebraically independent (over K) if:
* expression is a polynomial in 2 vars
* coefficients(E) = all coefficients of that polynomial
* zero_1 = zero of the algebra
* zero_2 = zero of sub-field
* valuation of E, is the value $f(\alpha,\beta)$ 

Hmm, let:
R1(x) <-> p( R2(x,z), all(y,R3(x,y)) ) is a fact for R1. It's a kind of sense, linked to R2, R3.
But R2 holds some sort of another sense like, R2 holds:
all(x,y) { R4(x) & R4(y) -> ( R2(x,y) <-> ex( z: R4(z), R5(z,x) & R5(z,y) )}
then R2 has *another sense*.

Hmm, if we think about relations as 1st class objects. x is called associative if (AxB)xC = Ax(BxC). So a rel/func has certain sense, if It *holds something*, some pattern formula.

R has *sense of order* if it holds: x R y, y R z -> x R z and x R y & y R x -> x = y. But sense of order is just 1-level sense, because It doesn't depend on any other thing.

We have dependent sense: if R1 has sense of order, and R2 holds: all(x){R2(x) -> all(y){ R1(y,x) -> y = x } }, then R2 has sense of *minimal*. But R2 has sense of minimal only in case R1 has sense of order. In fact, we can still define R2, as long as R1 is a binary rel. It's still valid, just doesn't make sense.

Ok, now if f has sense of spanning, ie. f holds: U subset f(U) and f(f(U)) = f(U), then It makes sense when we define "independent" wrt f, is independent(X) <-> all(x in X) { x not in f(X\\{x})}

In fact, we can define independent for any f, as long as f is a function that can apply on sets. However, this doesn't make sense like the way it's spanning set.

Ok, so this is basically how we define new thing, we build new concepts, we name things..
If we have R1 holds a fact like: p(R1) where p is a formula that takes R1 as var. For instance, p can be: all(x,y){ R(x,y) <-> R(y,x) }.
Hmm, we can call it a property of R1.

Now if we have a formula p(R1,R2,R3) for instance. And we have zfc |- p(R1,R2,R3) somehow.

We see the pattern zfc |- p(R1,R2,R3) is very common, popular for R1, R2, R3.. We see repetition of p (because we have eliminated Rj from p, p is now a formula in $1, $2, $3..) all the time.

Now p *becomes a sense*. A sense is actually a formula or few formulas that a group of relation hold.

Oh, but p1(R1,R2,R3), and p2(R3,R4), p3(R2,R4), p4(R2,R3,R4).. In reality, It's often like that. All of those p1, p2.. gathered to *become a sense*. We feel familiar with something if they hold the same *pattern*.

We have: $x_k \le \Sigma{x_j}$, $A_k \le \bigoplus{A_j}$ .. the pattern here is R(x_j,f(x)) holds along with isorder(R), is_sum(f). We feel *appropriate* here when we all f "sum". We don't feel f should be called "sum" if we don't have R(x_j, f(x)) holds. However, with negative numbers, we still have x + y < x. Yes, it reduces sense of sum. But not ruin it. So *sense must be something subjective*. It's a human-experience. It shouldn't be an exact definition like the way Category does.

Sense should be something to guide us for:
* develop new definition
* conjecture things

If we have a sense, i.e. a system p1(R1,R2,R3), p2(R3,R4), p3(R2,R4) for instance. They all hold. It's a sense. We have a def F concerning R1, R2..  Now we have p1(S1,S2,S3), p2(S3,S4), p3(S2,S4) hold. It'd be a good idea if we define F2 in term of S1, S2 in the same way that F being defined for R1, R2. That's how sense works. And if we have another fact about F, then it hints that we should question, does F2 hold the same fact?

Hmm, there's a pattern here. The pattern is the set {p1, p2..} of things that R1, R2.. hold.

Let take few example:
This is definiens of nat.divide
* params: n,m
* context: fix22(in,NAT)(m), fix22(in,NAT)(n)
* it <-> ex( k, fix22(in,NAT)(k) ) { m = nat.mul(n,k) }

Here we have fix22(in,NAT) and nat.mul. Or we can write: in, NAT, nat.mul, that is: R2, C, F2 where 2 is the arity.

We're gonna have corresponding $\Gamma$(R2) = ring.in, $\Gamma$(C) = A, $\Gamma$(F2) = ring.mul, but why? Why do we have this generalization? And why It's appropriate? So that we'll call the upcoming definition ring.divide(A)?

This is what we observe in world of NAT:

* P1: all(x,y: fix22(R2,C)(x) & fix22(R2,C)(y) ) {  F2(x,y) = F2(y,x) }
* P2: all(x,y,z: fix22(R2,C)(x) & fix22(R2,C)(y) & fix22(R2,C)(z) ) {  F2(F2(x,y),z) = F2(x,F2(y,z)) }

in fact, we have more if we have more objects: C2 to denote 0, C3 denote 1.. then we may write more:
* P3: all(x: fix22(R2,C)(x) ) { F2(x,C2) = C }
* P4: all(x: fix22(R2,C)(x) ) { F2(x,C1) = x }
* P5: fix22(R2,C)(C2)
* P6: fix22(R2,C)(C1)

Hmm, so here we have a collection {P1,P2,P3,P4,P5,P6}. That creates a *sense about algebra*. So for the ring, though It's intentional define a ring to be a structure that holds P1-P6, but anyway, it holds those conditions. That's why we tends to define divides for ring.

In fact, idea of ring, comes later. We earlier have that sense created from: NAT, INT, RAT, REAL, function spaces..

here: all(x,y: fix22(in,INT)(x), fix22(in,INT)(y)) { int.mul(x,y) = int.mul(y,x) }

From that solely fact, I don't think we'll extract in, INT and int.mul from that to get: all(x,y){ fix22(R2,C)(x), fix22(R2,C)(y) } { F2(x,y) = F2(y,x) }. Or may be we do. But point is, It comes from other *similar theorems*.

We have all(x,y: fix22(in,REAL)(x), fix22(in,REAL)(y)){ real.mul(x,y) = real.mul(y,x) }

If we eliminate all quanvars, then we see the *same pattern here*. Maybe that explains the origin of pattern, origin of senses.

For rings, group.. or literally any structure, they satisfy a precise amount of formula P1, P2.. P_n. But for a sense, we don't require it.

We have algebraically independent in the same way we define linearly independent. Why? Independent requires:
* expression
* coefficient:
* valuation
* zero_1
* zero_2

But it's just direct concerning stuffs. Generally we have:
* a type T for all cases: T can be: field, module.
* same base-context: T(F)
* vector space V ~ algebra A
* zero_2 of F, we have fix22(field.in,F)(zero_2) holds
* fix22(vector.space.in,V)(zero_1) ~ fix22(algebra.in,A)(zero_1)
* expression E in case of vector space, it's a pair of a formal expression e and a tuple of vectors t.
* expression E in case of algebra, it's a pair of a formal expression e and a tuple elements t.
* both holds: E = <e,t> & is_tuple(t) & all x in t, fix22(R.in,V)(x) & formal_expression(e)
* now we have formal expression e is..

hmm, we have sense about expression first, and sense about valuation first, and sense about zero first. That's why we call them by common word: expression, valuation, zero..

expression, valuation sense:
* expression(E) -> valuation(E) R.in the_space
* maybe more idk. or may be this is a bad example.

Point here is, we define independent, we use the same word, we define in same way.. We do it like the way we do it for Ring structure. But we don't need to define a new structure. We don't define a new structure like: (F,E,v,zero..) where F is field, E is expression relation, v is a valuation map, zero is element.. We technically can, but we just don't because in Math, this sort of structure very common. We just can't always do that. And we don't need to be serious with it.

Point here is there's phenomenon:
* few concrete objects: they're terms + relations + functions we don't care.
* they satisfy an eco system, ie system of formulas. This is often 5 - 20, 30 things.

Then we'll need to call them by certain name. A sense or something. They must be object of research.