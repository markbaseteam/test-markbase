I think a theorem is discovered by observing a pattern and try to generalize it.

Sources of a new theorem, I think:
* Observing a pattern, phenomenon, try to generalize it, then ask is this true? Like factorization in NAT, INT.. then factorization in any ring.
* If a conjecture is not true, how can we enforce the condition or loosen the conclusion to make it true?
* Ask if something is true in this theory, this context, then Is that true in general?
# Generalize a stuff
* Prime factorization in NAT, INT --> prime factorization in Ring --> prime factorization in Ideals
* All Cauchy sequences converge in REAL --> Cauchy sequences in any Banach space/Metric space/Topological space.

[[Generalization process]]

Hmm, generalizing a phenomenon often comes with generalizing definitions too.
NAT --> Ring
nat.add --> +
nat.mul --> *
nat.0 --> 0
nat.1 --> 1
nat.divide(x,y) <-> ex(k in NAT) { y = nat.mul(x,k) } -----> ring.divide(R)(x,y) <-> ex(k in base(R)) { y = ring.mul(R)(x,k) }
irreducible(x) <-> ( all y, z: x = y.z -> unit(y) or unit(z) ) ------> ring.irreducbile(R)(x) <-> ( all y, z: x = y.z -> unit y or unit z )

