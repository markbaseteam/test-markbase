A **connection** is a connection like this:
* For each $z \in \mathbb{C}$, there exists x, y $\in \mathbb{R}$ such that $z = x + iy$ 
* For each group G, there exists (B,\*) such that.. 
* 