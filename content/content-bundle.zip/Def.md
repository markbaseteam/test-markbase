this is main page about def. Here we present everything about it like we do with Wikipedia. If we need to work on it, we should create sub-pages for brain-storming.

a concept will be highlighted by green like this.

an open problem, a question will be highlighted by pink. Like, we need to work on it.

Here we'll try to observe phenomena and classify certain types of defs. For this, we can take some advanced theory to see a wider picture, what can be considered as a def.

# LIST PROBLEMS / QUESTIONS / PHENOMENA

parameters: G, x, how to group them? [[group.order,G],x] or [group.order,G,x]?

symbol being used: group, group_sub? group.sub? group.sub.normal? group.sub_normal?

meta-application in def: { a in x | p(a) } is a a def like [specification, x, p] or [specification, a, x, p(a) ]? Fraenkel.

structurize the def: and(R1,R2)(x), or [[and,R1,R2],x]. It's about organizing math

arity of defs, similar defs: union(x,y), union3(x,y,z), union4(x,y,z,t).. and, and3, and4, pair3, pair4..

structure: group(G), ring(R), topological group G,*,T, F-vectorspace V, G-set..

expressive power of haman-math: [ [and,map,[=,dom,X]], f ], we're talking about f is a map having dom = X. Or more complicated, [and,map,[=,dom,X],[range,[fix22,subset,NAT]]] is property that it's a map having dom X and range is subset of NAT.

type: fix22, and(R1,R2), non(R),.. we have expressive structure. think about Mizar.

has.unit, has.identity, has.zero, has.basis, has.something.. we have structure in symbol?

we have meta words: sub-, quotient-, span-, independent-.. that applies to many cases.

def by cases: if n > 0, if n <= 0

def by induction:

def by recursion:

def by construction: for z in C\0, ex. r, t in R, r >0 such that z = r*e^it. In that case, cos(t) is unique for any choice of t. We define foo(z) to be cos(t). That's a scenario in my head. In reality, it goes like that.

unique upto isomorphism: [[un_upto,R],a,x(a)] ~ ex(a,x(a)) & all(b,c, x(b) & x(c) -> R(b,c))
# DEF DESCRIPTION

We consider def is an object in our system. Its visualization can be a tuple or something. We're not sure, we decide later.

parameters: A def often has parameters. If we write subset(x,y) then its parameters are list [x,y].

symbol: A def often has a symbol: subset, eq, group, cos, nat, nat.add, nat.in,..

expression: it's a combination of symbol and parameters, like subset(x,y). Usually for simple math, It's symbol(params). But may be, It's symbol(param_group1)(param_group2).. is way more convenient in practice. Not sure.

context: I'm not sure this is a thing. Like if we have a def like: sqrt(x), then its context is condition on var, like: x in REAL, x >= 0.

or the def: abelian(G), then its context is group(G).

definiens: the content of def. For instance, in subset(x,y) then the definiens is: all(a) { a in x -> a in y }

It's a formula to talk about the def itself

the formula: the final formula come to the system, ie. it's an axiom added to the system.

like subset, its formula is: all(x,y){ x subset y <-> all(a){ a in x -> a in y } }

preformula: is the formula before we replace it by the expression, eg. for subset, it is all(x,y){ it <-> all(a){ a in x -> a in y } }
# HOW WE DEFINE IN REAL LIFE

directly: by providing

cases:

connection:

induction:

recursion:

# VALIDITY OF DEF

how we assure that a def is valid?