**Term** is part of John system. Here we want to approach everything in *abstract approach*, or axiomatic approach.

Abstract approach is the way we describe how it works, how it behaves, how it interacts with others instead of what it is.

For instance, we have concrete $S_{n}$ is a group. We have concrete elements $\sigma$, $\tau$.. of the group. They are (1,..n) or (16)(534)(2). They're concrete objects. Their multiplication is specified concretely by permutation operation on a specific set whose is \[1,..,n]. However when we describe it as group structure, we only care about its operator * between objects. We have (xy)z = x(yz) is a property of that structure. We don't care about specific elements.

| Concrete | Abstract |
| ------- | ------- |
| group $S_{n}$ | group |
| matrix | linear map |
| vectors (2,5) of $\mathbb{R}^2$ | vector space |
| $\mathbb{Q}[\sqrt2]$ | field |

The same principle applies here. History of Math proved that abstract approach always win in the sense that It enlarges our knowledge and generality about certain field: Topology, metric space, algebra.. or even Category Theory.

A concrete form of term is a list of list like this: (in,x,y). We want it stands for $x \in y$. But I'm not sure how can we generalize it to be an abstract theory. Like, a graph is a concrete object with nodes and vertices. And It must be that concrete. *Maybe a term must be that concrete*?
# Description
We have a molecule is the way we build a term.

# Questions
* Can we make theory about term abstract? axiomatic approach? Or It must be concrete like Graph Theory? In fact, It can always be generalized and can be approached in axiomatic method. Point is, is that helpful? May be the model with list of list is the best model.